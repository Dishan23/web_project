<?php
    session_start();
?>


    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title> User </title>
        <link href="../img/user.png" rel="icon">

        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous">

        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">

        <link href="../lib/css/style.css" rel="stylesheet" type="text/css">

        <link href="https://fonts.googleapis.com/css?family=Jura|Quicksand|Rajdhani" rel="stylesheet">


    </head>
    <?php 
	
	$user=$_SESSION['UserName'];

	if($user!="admin"){
		header("Location:../login.php");
	}
?>



    <body class="noselect">
        <div class="fixed sticky-top">
            <div class="logo">Smyrna Network <i class="fas fa-globe"></i></div>
            <div class="log"><a href="../functions/usrlogout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></div>
        </div>
        <div class="row col-12 p-0 m-0 px-0">
            <div class="col-2" id="fixed">
                <div class="nav flex-column" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                    <a class="nav-link tl" id="v-pills-home-tab" data-toggle="pill" href="#v-pills-home" role="tab" aria-controls="v-pills-home" aria-selected="true">My Site</a>

                    <a class="nav-link p-0 pt-1 m-0 mb-3 icon text-center" id="v-pills-home-tab" data-toggle="pill" href="#v-pills-home" role="tab" aria-controls="v-pills-home" aria-selected="true"><i class="fas fa-desktop"></i></a>

                    <a class="nav-link tl" id="v-pills-profile-tab" data-toggle="pill" href="#v-pills-profile" role="tab" aria-controls="v-pills-profile" aria-selected="false">Add Image</a>

                    <a class="nav-link p-0 pt-1 m-0 mb-3 icon text-center" id="v-pills-profile-tab" data-toggle="pill" href="#v-pills-profile" role="tab" aria-controls="v-pills-profile" aria-selected="true"><i class="fas fa-image"></i></a>

                    <a class="nav-link tl" id="v-pills-messages-tab" data-toggle="pill" href="#v-pills-messages" role="tab" aria-controls="v-pills-messages" aria-selected="false">Prayer Requests</a>

                    <a class="nav-link p-0 pt-1 m-0 mb-3 icon text-center" id="v-pills-messages-tab" data-toggle="pill" href="#v-pills-messages" role="tab" aria-controls="v-pills-messages" aria-selected="true"><i class="far fa-envelope"></i></a>

                    <a class="nav-link tl" id="v-pills-sermon-tab" data-toggle="pill" href="#v-pills-sermon" role="tab" aria-controls="v-pills-sermon" aria-selected="false">Add Sermon</a>

                    <a class="nav-link p-0 pt-1 m-0 mb-3 icon text-center" id="v-pills-sermon-tab" data-toggle="pill" href="#v-pills-sermon" role="tab" aria-controls="v-pills-sermon" aria-selected="true"><i class="fas fa-book-open"></i></a>

                    <a class="nav-link tl" id="v-pills-settings-tab" data-toggle="pill" href="#v-pills-settings" role="tab" aria-controls="v-pills-settings" aria-selected="false">Add Testimony</a>

                    <a class="nav-link p-0 pt-1 m-0 mb-3 icon text-center" id="v-pills-settings-tab" data-toggle="pill" href="#v-pills-settings" role="tab" aria-controls="v-pills-settings" aria-selected="true"><i class="far fa-comment"></i></a>

                    <a class="nav-link tl" id="v-pills-getTs-tab" data-toggle="pill" href="#v-pills-getTS" role="tab" aria-controls="v-pills-getTS" aria-selected="false">Get Testimony</a>

                    <a class="nav-link p-0 pt-1 m-0 mb-3 icon text-center" id="v-pills-getTs-tab" data-toggle="pill" href="#v-pills-getTS" role="tab" aria-controls="v-pills-getTS" aria-selected="false"><i class="far fa-comment-alt"></i></a>
                </div>
                <div class="row justify-content-between px-3 py-2 mt-2" id="social">
                    <a href="https://www.facebook.com/smyrnachurch.60.bogo" target="_blank"><i class="fab fa-facebook"></i></a>
                    <a href="https://twitter.com/SmyrnachBogo" target="_blank"><i class="fab fa-twitter"></i></a>
                    <a href="https://www.youtube.com/channel/UCWnc_ruzZjgT83xFGSmMsfQ" target="_blank"><i class="fab fa-youtube"></i></a>
                </div>
            </div>

            <div class="col-10" id="page">
                <div class="tab-content" id="v-pills-tabContent">
                    <div class="tab-pane fade show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
                        <div class="jumbotron m-0 py-2">
                            <h5>My Site</h5>
                            <hr class="m-0">
                            <p class="py-2">Here you can see what's going on your site!</p>
                            <div class="row">
                                <p class="col-lg-3 sm-12"><i class="fas fa-users"></i> Visiters Count : </p>
                                <P class="col-lg-2 sm-2">23</P>
                            </div>
                            <div class="row">
                                <p class="col-lg-3 sm-12"><i class="fas fa-envelope"></i> Prayer Requests Count : </p>
                                <P class="col-2">12</P>
                            </div>
                            <div class="row">
                                <p class="col-lg-3 sm-12"><i class="fas fa-comment-alt"></i> Testimony Count : </p>
                                <P class="col-2">8</P>
                            </div>


                            <a href="">
                        <button class="btn btn-outline-primary btn-sm">Visit to My site <i class="fas fa-angle-double-right"></i></button></a>

                        </div>
                    </div>
                    <div class="tab-pane fade" id="v-pills-profile" role="tabpanel" aria-labelledby="v-pills-profile-tab">
                        <h4 class="px-2 col-lg-4 sm-12 text-white">Add Image</h4>
                        <div class="jumbotron col-12 m-0 row ">
                            <div class="col-lg-4 sm-12">
                                <div class="">
                                    <label for="ImageTitle">Image Title</label>
                                </div>
                                <div class="form-group col-sm-12 p-0">
                                    <input type="text" id="imgt" placeholder="Title of Image" class="form-control form-control-sm">
                                </div>
                                <div>
                                    <label for="select slide">Select Slide</label>
                                </div>
                                <div class="form-group col-sm-12 p-0">
                                    <select class="form-control form-control-sm">
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                </select>
                                </div>
                                <div class="">
                                    <label for="ImageTitle">Select Image</label>
                                </div>
                                <div class="form-group col-sm-12 p-0">
                                    <input type="file" id="img" placeholder="Select Image" class="form-control form-control-sm">
                                </div>
                                <div class="form-group">
                                    <button class="btn btn-outline-dark btn-block btn-sm col-sm-12" id="btnimg" type="button">Add to Site</button>
                                </div>
                            </div>
                            <div class="col-lg-8 sm-12 text-center border border-danger">
                                <h5 class="my-3">The size is important! <i class="fas fa-ruler-combined"></i></h5>
                                <p>Must be 1366px <i class="fas fa-times"></i> 527px</p>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="v-pills-messages" role="tabpanel" aria-labelledby="v-pills-messages-tab">
                        <h4 class="px-2 col-lg-4 sm-12 text-white">Prayer Requests</h4>
                        <div class="jumbotron col-12 m-0 row" id="tbl">
                            <div class="col-12 border border-danger" id="pryReq">
                                <h5 class="text-center text-danger">This Section Dosen't Support For Mobile</h5>
                            </div>
                            <table class="table table-sm table-dark text-white replay">
                                <tr>
                                    <th><i class="fas fa-address-card"></i> Name</th>
                                    <th><i class="fas fa-envelope-open"></i> Prayer Request</th>
                                    <th><i class="fas fa-pencil-alt"></i> Address</th>
                                    <th><i class="fas fa-phone"></i> Contact</th>
                                    <th><i class="fas fa-at"></i> Email Id</th>
                                </tr>
                                <?php
                                require("../functions/dbConnection.php");
                                $obj=new dbConnection();
                                $con_db=$obj->getConnection();

                                //SELECT QUERY ----------
                                $sql="SELECT * FROM prayerreq";
                                $res=mysqli_query($con_db,$sql) or die("SERVER ERROR");
                                while($row=mysqli_fetch_array($res)){
                                    echo "<tr>
                                            <td>".$row['Name']."</td>
                                            <td>".$row['PrayerRqe']."</td>
                                            <td>".$row['Country']."</td>
                                            <td>".$row['Contact']."</td>
                                            <td>".$row['Email']."</td>

                                        </tr>";
                                }
                                //-----------------------

                                $obj->close($con_db);
                            ?>



                            </table>
                            <div class="col-12 replay">
                                <div>
                                    <hr>
                                    <h5>Replay section</h5>
                                    <hr>
                                </div>
                                <div class="">
                                    To
                                </div>
                                <div class="form-group">
                                    <input type="email" id="email" name="email" placeholder="E-Mail ID" class="form-control form-control-sm">
                                </div>
                                <div class="">
                                    Subject
                                </div>
                                <div class="form-group">
                                    <input type="text" id="subject" name="subject" placeholder="Subject" class="form-control form-control-sm">
                                </div>
                                <div class="">
                                    Replay
                                </div>
                                <div class="form-group">
                                    <textarea id="replay" name="replay" placeholder="Replay" class="form-control form-control-sm" rows="5"></textarea>
                                </div>
                                <button class="btn btn-outline-dark btn-sm" id="btnmail" type="button">Send</button>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="v-pills-settings" role="tabpanel" aria-labelledby="v-pills-settings-tab">
                        <h4 class="px-2 col-lg-4 sm-12 text-white">Add Testimony</h4>
                        <div class="jumbotron col-12 m-0 row">
                            <div class="container col-lg-8 sm-12">
                                <div>
                                    <label>Seclect Section</label>
                                </div>
                                <div class="col-12 row">
                                    <div class="form-group col-lg-2 sm-6 px-0">
                                        <select class="form-control" id="search">
                                <option value="1"> 1 </option>
                                <option value="2"> 2 </option>
                                <option value="3"> 3 </option>
                                <option value="4"> 4 </option>
                                <option value="5"> 5 </option>
                                <option value="6"> 6 </option>
                                </select>
                                    </div>
                                    <div class="col-lg-6 sm-12">
                                        <button class="btn btn-dark" id="find" type="button">Find</button>
                                    </div>
                                </div>
                                <div class="">
                                    <label for="Name">Name</label>
                                </div>
                                <div class="form-group">
                                    <input type="text" id="tsname" name="name" class="form-control" placeholder="Name">
                                </div>
                                <div>
                                    <label for="date">Date</label>
                                </div>
                                <div class="form-group">
                                    <input type="date" id="tsdate" name="tsdate" class="form-control">
                                </div>
                                <div class="">
                                    <label for="Name">Testimony</label>
                                </div>
                                <div class="form-group">
                                    <textarea type="text" id="txttestimony" name="testimony" placeholder="Testimony" class="form-control" rows="5"></textarea>
                                </div>
                                <div>
                                    <label for="img">Select Image</label>
                                </div>
                                <div class="custom-control custom-radio">
                                    <input type="radio" id="male" name="customRadio" class="custom-control-input">
                                    <label class="custom-control-label" for="male">Male</label>
                                </div>
                                <div class="custom-control custom-radio">
                                    <input type="radio" id="female" name="customRadio" class="custom-control-input" src="../Web/img/ladyusr.png">
                                    <label class="custom-control-label" for="female">Female</label>
                                </div>
                                <div class="mt-3">
                                    <button class="btn btn-outline-dark" id="addts" type="button">Add Testimony</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="tab-pane fade" id="v-pills-sermon" role="tabpanel" aria-labelledby="v-pills-sermon-tab">
                        <h4 class="px-2 col-lg-4 sm-12 text-white">Add Sermon</h4>
                        <div class="jumbotron col-12 m-0 row">
                            <div class="container col-lg-8 sm-12">
                                <div class="">
                                    <label for="Name">Pastor</label>
                                </div>
                                <div class="form-group">
                                    <input type="text" id="pastor" name="pastor" class="form-control form-control-sm" placeholder="Pastor's Name">
                                </div>
                                <div>
                                    <label for="title">Title of Sermon</label>
                                </div>
                                <div class="form-group">
                                    <input type="text" id="sertitle" name="sertitle" class="form-control form-control-sm" placeholder="Title">
                                </div>
                                <div class="">
                                    <label for="Name">Sermon</label>
                                </div>
                                <div class="form-group">
                                    <textarea type="text" id="sermon" name="sermon" placeholder="Sermon" class="form-control form-control-sm" rows="5"></textarea>
                                </div>
                                <div>
                                    <label for="date">Date</label>
                                </div>
                                <div class="form-group">
                                    <input type="date" id="serdate" name="serdate" class="form-control form-control-sm">
                                </div>
                                <div class="mt-3">
                                    <button class="btn btn-outline-dark btn-sm" id="btnser">Add Sermon</button>
                                </div>
                            </div>
                        </div>
                    </div>



                    <div class="tab-pane fade" id="v-pills-getTS" role="tabpanel" aria-labelledby="v-pills-getTS-tab">
                        <h4 class="px-2 col-lg-4 sm-12 text-white">Get Testimony</h4>
                        <div class="jumbotron col-12 m-0 row ">
                            <div class="col-12 border border-danger" id="pryReq2">
                                <h5 class="text-center text-danger">This Section Dosen't Support For Mobile</h5>
                            </div>
                            <table class="table table-sm table-dark text-white getts">
                                <tr class="col-12">
                                    <th><i class="fas fa-address-card"></i> Name</th>
                                    <th><i class="fas fa-envelope-open"></i> Testimony</th>
                                    <th><i class="fas fa-pencil-alt"></i> Address</th>
                                </tr>
                                <?php
                                $obj=new dbConnection();
                                $con_db=$obj->getConnection();
                                
                                $sql="SELECT * FROM testimony";
                                $res=mysqli_query($con_db,$sql) or die("SERVER ERROR");
                                while($row=mysqli_fetch_array($res)){
                                    echo "<tr>
                                            <td>".$row['fullName']."</td>
                                            <td>".$row['Testimony']."</td>
                                            <td>".$row['Country']."</td>

                                        </tr>";
                                }
                                

                                $obj->close($con_db);
                            ?>





                            </table>
                        </div>
                    </div>
                </div>
            </div>


        </div>

        <script src="../lib/js/jquery.js" type="text/javascript"></script>
        <script type="text/javascript">
            $(document).ready(function() {
                $("#find").click(function() {
                    var search = $("#search").val();
                    $.post("functions/findSection.php", {
                        search: search
                    }, function(data, status) {
                        if (status == "success") {
                            var arr = JSON.parse(data);


                            if (arr['flag'] == 1) {
                                $("#search").val(arr['sectionNo']);
                                $("#tsname").val(arr['Name']);
                                $("#tsdate").val(arr['Date']);
                                $("#txttestimony").val(arr['Testimony']);
                            } else {
                                alert("Canot find");
                            }
                        }
                    });
                });



                $("#addts").click(function() {
                    var sectionNo = $("#search").val();
                    var name = $("#tsname").val();
                    var date = $("#tsdate").val();
                    var testimony = $("#txttestimony").val();

                    if (name == "" || name == " ") {
                        swal({
                            title: "Oopss!",
                            text: "Type Name!!!",
                            icon: "error",
                            button: "Ok",
                        })
                    } else {
                        $.post("../functions/addtestimony.php", {
                            search: sectionNo,
                            tsname: name,
                            tsdate: date,
                            txttestimony: testimony
                        }, function(data, status) {
                            if (status == "success") {
                                swal({
                                        title: "Done!",
                                        text: "Successfully Added!",
                                        icon: "success",
                                        button: "Ok",
                                    })
                                    .then(val => {
                                        if (val) {
                                            location.reload();
                                        }
                                    });
                            }
                        });
                    }
                });


                $("#btnser").click(function() {
                    var pastor = $("#pastor").val();
                    var title = $("#sertitle").val();
                    var sermon = $("#sermon").val();
                    var date = $("#serdate").val();

                    if (pastor == "" || sermon == "") {
                        swal({
                            title: "Oopss!",
                            text: "Check Your Inputs!!!",
                            icon: "error",
                            button: "Ok",
                        });
                    } else {
                        $.post("../functions/addsermon.php", {
                            pastor: pastor,
                            sertitle: title,
                            sermon: sermon,
                            serdate: date
                        }, function(data, status) {
                            if (status == "success") {
                                swal({
                                        title: "Done!",
                                        text: "Successfully Added!",
                                        icon: "success",
                                        button: "Ok",
                                    })
                                    .then(val => {
                                        if (val) {
                                            location.reload();
                                        }
                                    });
                            } else {
                                swal({
                                    title: "ERROR!",
                                    text: "<----| ERROR |---->",
                                    icon: "error",
                                    button: "Ok",
                                });
                            }
                        });
                    }

                });









            });

        </script>










        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>

        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T" crossorigin="anonymous"></script>
    </body>

    </html>
