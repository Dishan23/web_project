<?php 

    $userName=$_POST["UserName"];
    $password=$_POST["PassWord"];
    $PASS=md5($password);

    require("dbConnection.php");

    $obj=new dbConnection();
    $con_db=$obj->getConnection();
    
    $sql="SELECT * FROM admin WHERE UserName='$userName' AND Password='$PASS';";

    $res=mysqli_query($con_db,$sql) or die("SERVER ERROR");
    $no_of_rec=$res->num_rows;
    if($no_of_rec==1){
        session_start();
        $_SESSION['UserName']=$userName;
        echo 1;
    }else{
        echo 0;
    }

    $obj->close($con_db);

?>
