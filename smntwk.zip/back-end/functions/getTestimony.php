<?php
    $name=$_POST["Tfname"];
    $country=$_POST["Tcty"];
    $Testimony=$_POST["Tes"];

    require("dbConnection.php");
    $obj=new dbConnection();
    $con_db=$obj->getConnection();

    $sql="INSERT INTO testimony (fullName, Country, Testimony) VALUES ('$name','$country', '$Testimony');";
    mysqli_query($con_db,$sql) or die ("ERROR");

    $obj->close($con_db);
    echo"Successfully Sent! We'll Update Your Testimony soon...";
?>
