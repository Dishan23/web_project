<?php

    $search=$_POST["search"];
    require("dbConnection.php");
    $obj=new dbConnection();
    $con_db=$obj->getConnection();


    $sql="SELECT * FROM addtestimony WHERE sectionNo='$search';";
    $res=mysqli_query($con_db,$sql) or die ("SERVER ERROR");

 $no=$res->num_rows;
    $a=array();
    if($no==1){
        $row=mysqli_fetch_array($res);
        $a=array(
            'sectionNo'=>['sectionNo'],
            'Name'=>$row['Name'],
            'Date'=>$row['Date'],
            'Testimony'=>$row['Testimony'],
            'flag'=>1       
        );
    }
else{
    $a=array(
        'sectionNo'=>"",
        'Name'=>"",
        'Date'=>"",
        'Testimony'=>"",
        'flag'=>0
    );
}
        echo json_encode($a);
        $obj->close($con_db);














?>
