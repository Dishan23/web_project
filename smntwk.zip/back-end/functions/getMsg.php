<?php
    $name=$_POST["fname"];
    $email=$_POST["cid"];
    $contact=$_POST["cno"];
    $country=$_POST["cty"];
    $PryReq=$_POST["msg"];

    require("dbConnection.php");
    $obj=new dbConnection();
    $con_db=$obj->getConnection();

    $sql="INSERT INTO Prayerreq (Name, Email, Contact, Country, PrayerRqe) VALUES ('$name','$email', '$contact', '$country', '$PryReq');";
    mysqli_query($con_db,$sql) or die ("ERROR");

    $obj->close($con_db);
    echo"Successfully Sent";
?>
