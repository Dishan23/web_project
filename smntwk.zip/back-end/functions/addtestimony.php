<?php

$sectionNo=$_POST["search"];
$name=$_POST["tsname"];
$date=$_POST["tsdate"];
$testimony=$_POST["txttestimony"];


require("dbConnection.php");
$obj=new dbConnection();
$con_db=$obj->getConnection();

$sql="UPDATE addtestimony SET Name='$name' ,Date='$date' ,Testimony='$testimony' WHERE sectionNo='$sectionNo';";

mysqli_query($con_db,$sql) or die ("ERROR");

$obj->close($con_db);
echo"OK";
?>
