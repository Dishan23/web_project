<?php
	session_start();
	session_destroy();
	if(isset($_SESSION['UserName'])){
		unset($_SESSION['UserName']);
	}
	header("Location:../login.php");
?>
