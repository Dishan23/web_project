<?php 
    class dbConnection{
    var $host;
    var $user;
    var $pass;
    var $db;


    function dbConnection(){
    $this->host="localhost";
    $this->user="root";
    $this->pass="";
    $this->db="smyrnanetwork";
    }

    function getConnection(){
        $con=mysqli_connect($this->host, $this->user, $this->pass, $this->db);
        return $con;
    }

    function close($con){
        mysqli_close($con);
    }
}
?>
