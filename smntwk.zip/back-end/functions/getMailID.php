<?php
    $email =$_POST["email"];
  

    require("dbConnection.php");
    $obj=new dbConnection();
    $con_db=$obj->getConnection();

    $sql="INSERT INTO subscribers (email) VALUES ('$email');";
    mysqli_query($con_db,$sql) or die ("ERROR");

    $obj->close($con_db);
    echo"Successfully Sent";
?>
