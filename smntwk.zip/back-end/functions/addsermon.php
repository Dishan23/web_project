<?php

    $pastor=$_POST["pastor"];
    $date=$_POST["serdate"];
    $title=$_POST["sertitle"];
    $sermon=$_POST["sermon"];

    require("dbConnection.php");
    $obj=new dbConnection();
    $con_db=$obj->getConnection();

    $sql="UPDATE addsermon SET Pastor='$pastor', Date='$date',Title='$title',Sermon='$sermon' WHERE ID='1';";

    mysqli_query($con_db,$sql) or die ("ERROR");

    $obj->close($con_db);
    echo"OK";
    



?>
