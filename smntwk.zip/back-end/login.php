<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <link href="img/user.png" rel="icon">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">



    <title> Smyrna Network </title>
</head>

<body class="bg-secondary">
    <div class="container col-lg-6 md-6 sm-12">
        <div class="jumbotron mt-5 text-center bg-dark border border-primary">
            <div class="container mb-3 md-3">
                <img src="img/user.png" width="75px;" height="75px;" onmousedown='return false;' onselectstart='return false;'>
            </div>
            <h4 for="login" class="text-primary" onmousedown='return false;' onselectstart='return false;'>Smyrna Network</h4>
            <br>
            <div class="col-auto">
                <label class="text-white" for="UserName" onmousedown='return false;' onselectstart='return false;'>User Name</label>
                <div class="input-group mb-4">
                    <div class="input-group-prepend">
                        <div class="input-group-text"><i class="fas fa-user-tie"></i></div>
                    </div>
                    <input type="text" class="form-control" id="UserName" placeholder="Username">
                </div>
            </div>
            <div class="alert alert-danger" id="err" style="display: none;" onmousedown='return false;' onselectstart='return false;'>
                Type Correct User Name!!!
            </div>
            <div class="col-auto" id="Password" style="display:none ;">
                <label class="text-white" for="PassWord" onmousedown='return false;' onselectstart='return false;'>Password</label>
                <div class="input-group mb-4">
                    <div class="input-group-prepend">
                        <div class="input-group-text"><i class="fas fa-lock"></i></div>
                    </div>
                    <input type="password" class="form-control" id="PassWord" placeholder="Password">
                </div>
            </div>
            <div class="alert alert-danger" id="err2" style="display: none;" onmousedown='return false;' onselectstart='return false;'>
                Type User Name!!!
            </div>
            <div class="mb-3" id="btnck" style="display:block ">
                <button class="btn btn-success col-8" id="btnck" onmousedown='return false;' onselectstart='return false;'>Verify</button>
            </div>
            <div class="mb-3" id="btnlogin" style="display:none ">
                <button class="btn btn-primary col-8" id="btnlogin" type="button" onmousedown='return false;' onselectstart='return false;'>Login</button>
            </div>
        </div>
    </div>







    <script type="text/javascript" src="../Functions/jquery.js"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $("#btnck").click(function() {
                var userName = $("#UserName").val();

                if (userName == "admin") {
                    swal({
                        title: "Done!",
                        text: "User Name Matched!!!",
                        icon: "success",
                        button: "Ok",
                    })
                    $("#Password").css("display", "block");
                    $("#btnlogin").css("display", "block");
                    $("#btnck").css("display", "none");
                    $("#err").css("display", "none");
                } else {
                    swal({
                        title: "Oopss!",
                        text: "User Name Doesn't Match!!!",
                        icon: "error",
                        button: "Ok",
                    })
                    $("#err").css("display", "block");
                }
            });
        });

    </script>
    <script type="text/javascript">
        $(document).ready(function() {
            $("#btnlogin").click(function() {
                var userName = $("#UserName").val();
                var pass = $("#PassWord").val();

                if (pass == "") {

                    $("#err2").css("display", "block");
                    $("#err2").html("Please Type Your Password!!!");
                } else {
                    $.post("functions/usrlogin.php", {
                        UserName: userName,
                        PassWord: pass
                    }, function(data, status) {
                        if (status == "success") {
                            if (data == 1) {
                                window.location.href = "user/user.php";

                            } else {
                                $("#err2").css("display", "block");
                                $("#err2").html("Invalid Password!!");
                            }
                        }
                    });
                };
            });
        });

    </script>

    <!---------------------------------------------------------------------------------------------------------------------->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">

    <!---------------------------------------------------------------------------------------------------------------------->


</body>

</html>
